# MediPharma Connect - Webseite

Eine professionelle, DSGVO-konforme Webseite für MediPharma Connect mit modernem Design, SEO-Optimierung und HubSpot-Integration.

## 🚀 Features

### ✅ Design & Branding
- **Farbschema**: #033853 (Primär) und #28b4ac (Sekundär)
- **Typografie**: Inter für Headlines, Open Sans für Fließtext
- **Responsive Design**: Optimiert für Desktop, Tablet und Mobile
- **Moderne Animationen**: Smooth Scrolling, Hover-Effekte, Fade-in Animationen

### ✅ Sektionen
1. **Hero-Section**: Überzeugende Headline mit interaktivem Dashboard-Mock
2. **Für Unternehmen**: Tab-Navigation mit Dienstleistungen und Lead Magnet
3. **Für Dienstleister**: Prozess-Timeline und interaktives Quiz
4. **Über uns**: Mission, Vision, Werte und Meilensteine
5. **Kontakt**: Kontaktformular und HubSpot-Kalender-Integration

### ✅ Interaktive Elemente
- **Quiz-Funktionalität**: "Sind Sie auditierbar?" mit Fortschrittsbalken
- **Tab-Navigation**: Für Dienstleistungen
- **Smooth Scrolling**: Navigation zwischen Sektionen
- **Hover-Effekte**: Auf Cards und Buttons
- **Mobile Navigation**: Hamburger-Menü für mobile Geräte

### ✅ HubSpot-Integration
- **Meetings-Embed**: Direkter Terminbuchungskalender von Manuel Kessen
- **Kontaktformular**: Mit DSGVO-Checkbox
- **Lead Magnets**: Kostenlose Checkliste zum Download

### ✅ SEO & DSGVO
- **Meta-Tags**: Optimiert für Keywords wie "Lieferantenqualifizierung Pharma"
- **Alt-Tags**: Für alle Bilder
- **DSGVO-Links**: Datenschutzerklärung, Impressum, AGB
- **Strukturierte Daten**: Für bessere Suchmaschinen-Indexierung

## 🛠 Technologie-Stack

- **Framework**: React 18 mit Vite
- **Styling**: Tailwind CSS mit Custom Design System
- **Icons**: Lucide React
- **Fonts**: Google Fonts (Inter, Open Sans)
- **Build**: Optimiert für Production

## 📱 Responsive Design

Die Webseite ist vollständig responsive und optimiert für:
- **Desktop**: 1920px+
- **Laptop**: 1024px - 1919px
- **Tablet**: 768px - 1023px
- **Mobile**: 320px - 767px

## 🎯 Conversion-Optimierung

### Lead-Generierung
- **Primärer CTA**: "Jetzt kostenloses Erstgespräch buchen"
- **Sekundärer CTA**: "Mehr erfahren"
- **Lead Magnet**: Kostenlose Checkliste
- **Quiz**: Interaktive Selbsteinschätzung

### Trust-Building
- **Erfolgsstatistiken**: +45% Umsatzsteigerung, -60% Audit-Aufwand
- **Qualitätsversprechen**: 100% GDP/GMP Konformität
- **Prozess-Transparenz**: Klare 4-Schritte Timeline

## 🚀 Deployment

### Lokale Entwicklung
```bash
cd medipharma-connect
pnpm install
pnpm run dev
```

### Production Build
```bash
pnpm run build
```

Die Build-Dateien befinden sich im `dist/` Ordner und sind bereit für die Bereitstellung.

## 📊 Performance

- **Optimierte Assets**: Komprimierte Bilder und CSS
- **Code Splitting**: Automatisch durch Vite
- **Lazy Loading**: Für bessere Performance
- **SEO-Ready**: Strukturierte Meta-Tags

## 🔧 Wartung

### Inhalte aktualisieren
- Texte können direkt in den React-Komponenten bearbeitet werden
- Bilder im `src/assets/` Ordner austauschen
- Farben über CSS-Variablen in `App.css` anpassen

### HubSpot-Integration
- Meetings-URL in `src/components/Kontakt.jsx` anpassen
- Formular-Handling kann erweitert werden

## 📞 Support

Bei Fragen oder Anpassungswünschen wenden Sie sich an das Entwicklungsteam.

---

**© 2024 MediPharma Connect. Alle Rechte vorbehalten.**

