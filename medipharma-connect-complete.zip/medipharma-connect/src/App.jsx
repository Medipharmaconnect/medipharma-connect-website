import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HeroSection from './components/HeroSection';
import FuerUnternehmen from './components/FuerUnternehmen';
import FuerDienstleister from './components/FuerDienstleister';
import UeberUns from './components/UeberUns';
import Kontakt from './components/Kontakt';
import './App.css';

function App() {
  return (
    <div className="App font-body">
      <Header />
      <main>
        <HeroSection />
        <FuerUnternehmen />
        <FuerDienstleister />
        <UeberUns />
        <Kontakt />
      </main>
      <Footer />
    </div>
  );
}

export default App;
