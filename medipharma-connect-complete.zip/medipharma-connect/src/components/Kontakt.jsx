import React, { useState, useEffect } from 'react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Send,
  CheckCircle,
  Calendar
} from 'lucide-react';

const Kontakt = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    message: '',
    privacy: false
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  // HubSpot Meetings Script laden
  useEffect(() => {
    // HubSpot Meetings Script dynamisch laden
    const script = document.createElement('script');
    script.src = 'https://static.hsappstatic.net/MeetingsEmbed/ex/MeetingsEmbedCode.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      // Cleanup
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.privacy) {
      alert('Bitte stimmen Sie der Datenschutzerklärung zu.');
      return;
    }
    
    // Hier würde normalerweise die Formular-Übermittlung stattfinden
    console.log('Form submitted:', formData);
    setIsSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: '',
        company: '',
        email: '',
        message: '',
        privacy: false
      });
    }, 3000);
  };

  return (
    <section id="kontakt" className="py-20 bg-gradient-mpc-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-mpc-primary mb-6">
            Lassen Sie uns{' '}
            <span className="text-mpc-secondary">15 Minuten</span>{' '}
            über Ihre Prozesse sprechen
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-body">
            Vereinbaren Sie ein kostenloses Erstgespräch und erfahren Sie, 
            wie MediPharma Connect Ihre Lieferantenqualifizierung optimieren kann.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Kontaktinformationen */}
          <div>
            <div className="bg-white rounded-2xl p-8 shadow-sm mb-8">
              <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-6">
                Kontaktinformationen
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-mpc-secondary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Mail className="h-6 w-6 text-mpc-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-mpc-primary mb-1">E-Mail</h4>
                    <p className="text-gray-600">info@medipharmaconnect.com</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-mpc-secondary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Phone className="h-6 w-6 text-mpc-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-mpc-primary mb-1">Telefon</h4>
                    <p className="text-gray-600">+49 (0) 123 456 789</p>
                    <p className="text-gray-500 text-sm">Mo-Fr: 9:00 - 17:00 Uhr</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-mpc-secondary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-6 w-6 text-mpc-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-mpc-primary mb-1">Adresse</h4>
                    <p className="text-gray-600">
                      MediPharma Connect<br />
                      Nützenbergerstr. 141<br />
                      42115 Wuppertal<br />
                      Deutschland
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-mpc-secondary/20 rounded-full flex items-center justify-center flex-shrink-0">
                    <Clock className="h-6 w-6 text-mpc-secondary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-mpc-primary mb-1">Geschäftszeiten</h4>
                    <p className="text-gray-600">
                      Montag - Freitag: 9:00 - 17:00 Uhr<br />
                      Samstag - Sonntag: Geschlossen
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Kontaktformular */}
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-6">
                Nachricht senden
              </h3>
              
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                        Name *
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mpc-secondary focus:border-transparent transition-all duration-200"
                        placeholder="Ihr vollständiger Name"
                      />
                    </div>
                    <div>
                      <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-2">
                        Unternehmen *
                      </label>
                      <input
                        type="text"
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mpc-secondary focus:border-transparent transition-all duration-200"
                        placeholder="Ihr Unternehmen"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      E-Mail-Adresse *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mpc-secondary focus:border-transparent transition-all duration-200"
                      placeholder="ihre.email@unternehmen.de"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                      Nachricht
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mpc-secondary focus:border-transparent transition-all duration-200"
                      placeholder="Beschreiben Sie kurz Ihr Anliegen..."
                    />
                  </div>

                  <div className="flex items-start space-x-3">
                    <input
                      type="checkbox"
                      id="privacy"
                      name="privacy"
                      checked={formData.privacy}
                      onChange={handleInputChange}
                      required
                      className="mt-1 h-4 w-4 text-mpc-secondary focus:ring-mpc-secondary border-gray-300 rounded"
                    />
                    <label htmlFor="privacy" className="text-sm text-gray-600">
                      Ich stimme der{' '}
                      <button 
                        type="button"
                        className="text-mpc-secondary hover:underline"
                        onClick={() => document.getElementById('datenschutz')?.scrollIntoView({ behavior: 'smooth' })}
                      >
                        Datenschutzerklärung
                      </button>{' '}
                      zu und bin damit einverstanden, dass meine Daten zur Bearbeitung 
                      meiner Anfrage gespeichert werden. *
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-mpc-secondary text-white px-6 py-3 rounded-lg hover:bg-opacity-90 transition-all duration-200 font-medium hover-lift flex items-center justify-center"
                  >
                    <Send className="mr-2 h-5 w-5" />
                    Nachricht senden
                  </button>
                </form>
              ) : (
                <div className="text-center py-8">
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <h4 className="text-xl font-semibold text-mpc-primary mb-2">
                    Vielen Dank für Ihre Nachricht!
                  </h4>
                  <p className="text-gray-600">
                    Wir werden uns schnellstmöglich bei Ihnen melden.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* HubSpot Kalender */}
          <div>
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="text-center mb-6">
                <Calendar className="h-12 w-12 text-mpc-secondary mx-auto mb-4" />
                <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-2">
                  Direkter Terminbuchung
                </h3>
                <p className="text-gray-600">
                  Buchen Sie direkt einen Termin für Ihr kostenloses Erstgespräch
                </p>
              </div>

              {/* HubSpot Meetings Embed */}
              <div className="meetings-iframe-container" data-src="https://meetings.hubspot.com/mkessen?embed=true">
                {/* Fallback Content */}
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <Calendar className="h-16 w-16 text-mpc-secondary mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-mpc-primary mb-2">
                    Terminbuchung wird geladen...
                  </h4>
                  <p className="text-gray-600 mb-4">
                    Falls die Terminbuchung nicht lädt, kontaktieren Sie uns gerne direkt:
                  </p>
                  <a 
                    href="mailto:info@medipharmaconnect.com"
                    className="inline-flex items-center text-mpc-secondary hover:underline"
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    info@medipharmaconnect.com
                  </a>
                </div>
              </div>
            </div>

            {/* Vorteile des Erstgesprächs */}
            <div className="mt-8 bg-gradient-mpc text-white rounded-2xl p-6">
              <h4 className="text-lg font-semibold mb-4">Was Sie im Erstgespräch erwartet:</h4>
              <ul className="space-y-2 text-sm opacity-90">
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                  Kostenlose Bedarfsanalyse Ihrer aktuellen Prozesse
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                  Individuelle Lösungsvorschläge für Ihr Unternehmen
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                  Transparente Aufklärung über Kosten und Zeitrahmen
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                  Keine Verpflichtungen - reine Informationsveranstaltung
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Kontakt;

