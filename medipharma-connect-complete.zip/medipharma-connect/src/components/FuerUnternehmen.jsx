import React, { useState } from 'react';
import { 
  Clock, 
  FileCheck, 
  Zap, 
  BarChart3, 
  CheckCircle, 
  Download,
  ArrowRight,
  Users,
  Shield,
  Target
} from 'lucide-react';

const FuerUnternehmen = () => {
  const [activeTab, setActiveTab] = useState('zentrale-qualifizierung');

  const services = {
    'zentrale-qualifizierung': {
      title: 'Zentrale Qualifizierung',
      description: 'Einmalige Auditierung für alle Ihre Dienstleister',
      features: [
        'GDP/GMP-konforme Auditierung nach internationalen Standards',
        'Dokumentation aller Qualitätsprozesse',
        'Zertifikatsverwaltung und Gültigkeitsüberwachung',
        'Kontinuierliche Überwachung der Compliance'
      ],
      stat: '100%',
      statLabel: 'GDP/GMP Konformität'
    },
    'auditberichte-abruf': {
      title: 'Auditberichte auf Abruf',
      description: 'Sofortiger Zugang zu allen Auditdokumenten',
      features: [
        'Digitale Berichte binnen 24h verfügbar',
        'Strukturierte Bewertung nach Ihren KPIs',
        'Historische Datenanalyse und Trends',
        'Export in verschiedene Formate'
      ],
      stat: '24h',
      statLabel: 'Verfügbarkeit'
    },
    're-audits-monitoring': {
      title: 'Re-Audits & Monitoring',
      description: 'Kontinuierliche Überwachung Ihrer Partner',
      features: [
        'Automatische Erinnerungen vor Ablauf',
        'Risikobewertung und Priorisierung',
        'Kontinuierliches Performance-Monitoring',
        'Proaktive Benachrichtigungen bei Änderungen'
      ],
      stat: '365',
      statLabel: 'Tage Monitoring'
    },
    'capa-management': {
      title: 'CAPA-Management',
      description: 'Professionelle Abweichungsbehandlung',
      features: [
        'Strukturierte Erfassung von Abweichungen',
        'Workflow-Management für Korrekturmaßnahmen',
        'Nachverfolgung bis zur vollständigen Umsetzung',
        'Integration in bestehende QM-Systeme'
      ],
      stat: '100%',
      statLabel: 'Nachverfolgung'
    }
  };

  return (
    <section id="fuer-unternehmen" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            FÜR UNTERNEHMEN
          </div>
          <h2 className="text-4xl font-heading font-bold text-mpc-primary mb-6">
            Lieferantenqualifizierung endlich effizient
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Zeit- und Ressourceneinsparung durch Nutzung eines zentralen, auditierten 
            Dienstleisternetzwerks. Reduzieren Sie Ihren Aufwand und beschleunigen Sie Ihre Prozesse.
          </p>
        </div>

        {/* Vorteile Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Nur 1 Audit</h3>
            <p className="text-gray-600 text-sm">für alle Dienstleister</p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileCheck className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Revisionssicher</h3>
            <p className="text-gray-600 text-sm">Auditberichte verfügbar</p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Schneller</h3>
            <p className="text-gray-600 text-sm">Prozess & Integration</p>
          </div>

          <div className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Monitoring</h3>
            <p className="text-gray-600 text-sm">Kontinuierliche Überwachung</p>
          </div>
        </div>

        {/* Services Section */}
        <div className="bg-white rounded-2xl p-8 mb-16">
          <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-8 text-center">
            Unsere Dienstleistungen für Sie
          </h3>
          
          {/* Tab Navigation */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {Object.entries(services).map(([key, service]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  activeTab === key
                    ? 'bg-mpc-secondary text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {service.title}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h4 className="text-xl font-semibold text-mpc-primary mb-4">
                {services[activeTab].title}
              </h4>
              <p className="text-gray-600 mb-6">
                {services[activeTab].description}
              </p>
              <ul className="space-y-3">
                {services[activeTab].features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-mpc-secondary mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="text-center">
              <div className="bg-gradient-to-br from-mpc-primary to-mpc-secondary text-white p-8 rounded-2xl">
                <div className="text-4xl font-bold mb-2">
                  {services[activeTab].stat}
                </div>
                <div className="text-lg opacity-90">
                  {services[activeTab].statLabel}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Lead Magnet */}
        <div className="bg-gradient-to-r from-mpc-primary to-mpc-secondary text-white rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-heading font-bold mb-4" style={{ color: '#033853' }}>
            Kostenlose Checkliste: Lieferantenqualifizierung in 5 Tagen
          </h3>
          <p className="text-lg mb-6" style={{ color: '#033853' }}>
            Erhalten Sie unseren bewährten Leitfaden für eine effiziente Qualifizierung
          </p>
          <button className="bg-white text-mpc-primary px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors inline-flex items-center">
            <Download className="mr-2 h-5 w-5" />
            Jetzt kostenlos herunterladen
          </button>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <button className="bg-mpc-secondary text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-mpc-secondary/90 transition-colors inline-flex items-center">
            Jetzt kostenloses Beratungsgespräch vereinbaren
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default FuerUnternehmen;

