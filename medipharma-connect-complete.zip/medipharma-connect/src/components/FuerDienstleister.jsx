import React, { useState } from 'react';
import { 
  Award, 
  TrendingUp, 
  Users, 
  CheckCircle, 
  ArrowRight,
  Star,
  Target,
  Handshake,
  BarChart3,
  Clock
} from 'lucide-react';

const FuerDienstleister = () => {
  const [quizStep, setQuizStep] = useState(0);
  const [quizAnswers, setQuizAnswers] = useState({});

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const quizQuestions = [
    {
      question: "Wie oft werden Sie pro Jahr von Kunden auditiert?",
      options: ["A) Mehr als 5x", "B) 2–4x", "C) 1x", "D) Noch nie"]
    },
    {
      question: "Welche dieser Zertifizierungen besitzen Sie?",
      options: ["A) GDP & ISO 9001", "B) Nur ISO 9001", "C) Nur GDP", "D) Keine"]
    },
    {
      question: "Wie gehen Sie mit Kundenanforderungen zur Qualifizierung um?",
      options: [
        "A) Wir haben einen festen Prozess mit dediziertem Personal",
        "B) Wir reagieren, sobald eine Anfrage kommt",
        "C) Wir nutzen Vorlagen & Excel-Listen",
        "D) Wir sind uns nicht sicher, was Kunden überhaupt erwarten"
      ]
    },
    {
      question: "Wo speichern Sie Ihre Auditberichte und Zertifikate?",
      options: [
        "A) Zentral digital in einem QMS",
        "B) Lokal auf dem Server",
        "C) In verschiedenen E-Mail-Postfächern",
        "D) Überhaupt nicht systematisch"
      ]
    },
    {
      question: "Wer kümmert sich bei Ihnen um CAPA-Management?",
      options: [
        "A) Ein dediziertes QM-Team mit digitalen Tools",
        "B) Die Geschäftsleitung manuell",
        "C) Unterschiedlich, je nach Fall",
        "D) Wir haben keinen festgelegten Prozess"
      ]
    },
    {
      question: "Wie viele Anfragen zur Auditierung neuer Kunden-Dienstleister erhalten Sie pro Jahr?",
      options: ["A) Über 10", "B) 5–10", "C) 1–4", "D) Keine"]
    },
    {
      question: "Nutzen Sie ein strukturiertes KPI-Monitoring?",
      options: [
        "A) Ja, voll automatisiert",
        "B) Teilweise, mit Excel oder BI-Tools",
        "C) Nur in einzelnen Bereichen",
        "D) Nein"
      ]
    }
  ];

  const handleQuizAnswer = (answer) => {
    const newAnswers = { ...quizAnswers, [quizStep]: answer };
    setQuizAnswers(newAnswers);
    
    if (quizStep < quizQuestions.length - 1) {
      setQuizStep(quizStep + 1);
    } else {
      // Quiz completed - show result
      setQuizStep(quizQuestions.length);
    }
  };

  const resetQuiz = () => {
    setQuizStep(0);
    setQuizAnswers({});
  };

  return (
    <section id="fuer-dienstleister" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-block bg-teal-100 text-teal-800 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            FÜR DIENSTLEISTER
          </div>
          <h2 className="text-4xl font-heading font-bold text-mpc-primary mb-6">
            Mehr Aufträge. Weniger Audits.
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Neutrale Auditierung & Sichtbarkeit im MPC-Netzwerk. Einmalige Zertifizierung 
            für Zugang zu unserem wachsenden Kundenstamm.
          </p>
        </div>

        {/* Vorteile Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div className="text-center p-6 bg-gray-50 rounded-xl hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Einmalige Auditierung</h3>
            <p className="text-gray-600 text-sm">für viele Kunden</p>
          </div>

          <div className="text-center p-6 bg-gray-50 rounded-xl hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Qualitätssiegel</h3>
            <p className="text-gray-600 text-sm">für bessere Marktposition</p>
          </div>

          <div className="text-center p-6 bg-gray-50 rounded-xl hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Netzwerk-Zugang</h3>
            <p className="text-gray-600 text-sm">zu neuen Kunden</p>
          </div>

          <div className="text-center p-6 bg-gray-50 rounded-xl hover:shadow-md transition-shadow">
            <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="h-8 w-8 text-mpc-secondary" />
            </div>
            <h3 className="font-semibold text-mpc-primary mb-2">Lead-Generierung</h3>
            <p className="text-gray-600 text-sm">durch Empfehlungen</p>
          </div>
        </div>

        {/* Prozess Timeline */}
        <div className="bg-gray-50 rounded-2xl p-8 mb-16">
          <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-8 text-center">
            Ihr Weg ins MediPharma Connect Netzwerk
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-mpc-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h4 className="font-semibold text-mpc-primary mb-2">Erstgespräch</h4>
              <p className="text-gray-600 text-sm">Kostenlose Beratung und Bedarfsanalyse</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-mpc-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h4 className="font-semibold text-mpc-primary mb-2">Audit-Planung</h4>
              <p className="text-gray-600 text-sm">Terminierung und Vorbereitung des Audits</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-mpc-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h4 className="font-semibold text-mpc-primary mb-2">Zertifizierung</h4>
              <p className="text-gray-600 text-sm">GDP/GMP-konforme Auditierung vor Ort</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-mpc-secondary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                4
              </div>
              <h4 className="font-semibold text-mpc-primary mb-2">Netzwerk-Aufnahme</h4>
              <p className="text-gray-600 text-sm">Zugang zu Kunden und Lead-Generierung</p>
            </div>
          </div>
        </div>

        {/* Qualitäts-Quick-Check */}
        <div className="bg-white rounded-2xl p-8 mb-16">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-4">
              Qualitäts-Quick-Check: Wo steht Ihr Unternehmen heute?
            </h3>
            <p className="text-gray-600 mb-2">
              Beantworten Sie die folgenden Fragen, um herauszufinden, wie fit Ihr Unternehmen 
              in Sachen Qualität, Auditierung und Zertifizierung ist.
            </p>
            <p className="text-sm text-mpc-secondary font-semibold">Dauer: 2 Minuten</p>
          </div>
          
          {quizStep < quizQuestions.length ? (
            <div className="max-w-2xl mx-auto">
              <div className="mb-6">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Frage {quizStep + 1} von {quizQuestions.length}</span>
                  <span>{Math.round(((quizStep) / quizQuestions.length) * 100)}% abgeschlossen</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-mpc-secondary h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(quizStep / quizQuestions.length) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="text-center">
                <h4 className="text-xl font-semibold text-mpc-primary mb-6">
                  {quizQuestions[quizStep].question}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {quizQuestions[quizStep].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleQuizAnswer(option)}
                      className="p-4 border-2 border-gray-200 rounded-lg hover:border-mpc-secondary hover:bg-mpc-secondary/5 transition-all duration-200 text-left"
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto text-center">
              <h4 className="text-xl font-semibold text-mpc-primary mb-6">
                🧾 Ihre Auswertung
              </h4>
              <div className="space-y-4 text-left mb-8">
                <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
                  <p className="font-semibold text-green-800">✔️ Hohe Qualitätsreife (6-7x A-Antworten):</p>
                  <p className="text-green-700">Sie sind bereits auf einem sehr hohen Niveau – mit MediPharma Connect sparen Sie dennoch Zeit und steigern Ihre Sichtbarkeit.</p>
                </div>
                <div className="p-4 bg-yellow-50 border-l-4 border-yellow-500 rounded">
                  <p className="font-semibold text-yellow-800">⚙️ Solide Basis (3-5x A/B-Antworten):</p>
                  <p className="text-yellow-700">Sie haben solide Strukturen – wir helfen Ihnen, sie zu standardisieren und auditfest zu machen.</p>
                </div>
                <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded">
                  <p className="font-semibold text-red-800">🚨 Handlungsbedarf (Mehrheit C/D-Antworten):</p>
                  <p className="text-red-700">Zeit zu handeln – wir bringen Sie auf ein qualifiziertes Level, das Kunden und Auditoren überzeugt.</p>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => scrollToSection('kontakt')}
                  className="bg-mpc-secondary text-white px-6 py-3 rounded-lg hover:bg-opacity-90 transition-all duration-200 font-medium hover-lift"
                >
                  Jetzt Beratung anfragen
                </button>
                <button 
                  onClick={resetQuiz}
                  className="border-2 border-mpc-primary text-mpc-primary px-6 py-3 rounded-lg hover:bg-mpc-primary hover:text-white transition-all duration-200 font-medium"
                >
                  Quiz wiederholen
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Warum Unternehmen MediPharma Connect wählen */}
        <div className="bg-white rounded-2xl p-8 mb-16">
          <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-8 text-center">
            Warum Unternehmen MediPharma Connect wählen
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6 bg-gradient-mpc-light rounded-xl">
              <Clock className="h-12 w-12 text-mpc-secondary mx-auto mb-4" />
              <div className="text-2xl font-bold text-mpc-primary mb-2">Bis zu 70%</div>
              <div className="text-gray-600">Zeitersparnis bei der Lieferantenqualifizierung</div>
            </div>

            <div className="text-center p-6 bg-gradient-mpc-light rounded-xl">
              <CheckCircle className="h-12 w-12 text-mpc-secondary mx-auto mb-4" />
              <div className="text-2xl font-bold text-mpc-primary mb-2">Einheitliche</div>
              <div className="text-gray-600">Standards für alle Ihre Dienstleister</div>
            </div>

            <div className="text-center p-6 bg-gradient-mpc-light rounded-xl">
              <Target className="h-12 w-12 text-mpc-secondary mx-auto mb-4" />
              <div className="text-2xl font-bold text-mpc-primary mb-2">Automatisierte</div>
              <div className="text-gray-600">Prozesse statt manueller Verwaltung</div>
            </div>

            <div className="text-center p-6 bg-gradient-mpc-light rounded-xl">
              <TrendingUp className="h-12 w-12 text-mpc-secondary mx-auto mb-4" />
              <div className="text-2xl font-bold text-mpc-primary mb-2">Fokus aufs</div>
              <div className="text-gray-600">Kerngeschäft statt Audit-Bürokratie</div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <button className="bg-mpc-secondary text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-mpc-secondary/90 transition-colors inline-flex items-center">
            Jetzt Auditierung anfragen
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default FuerDienstleister;

