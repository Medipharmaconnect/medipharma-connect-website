import React from 'react';
import { 
  Shield, 
  Target, 
  Eye, 
  CheckCircle, 
  Award,
  Users,
  TrendingUp,
  Globe
} from 'lucide-react';

const UeberUns = () => {
  const milestones = [
    {
      year: '2024',
      title: 'Gründung von MediPharma Connect',
      description: 'Start mit der Vision einer zentralen Qualifizierungsplattform'
    },
    {
      year: '2024',
      title: 'Erste Partnerschaften',
      description: 'Aufbau des initialen Netzwerks mit führenden Pharma-Dienstleistern'
    },
    {
      year: '2024',
      title: 'GDP/GMP Akkreditierung',
      description: 'Offizielle Anerkennung als qualifizierte Auditierungsstelle'
    },
    {
      year: '2025',
      title: 'ISO-Zertifikat erhalten',
      description: 'Erhalt unseres ISO-Zertifikats, was es uns erlaubt das erste auditierte Dienstleister Netzwerk der Pharma Branche aufzubauen'
    },
    {
      year: '2025',
      title: 'Netzwerk-Expansion',
      description: 'Geplante Erweiterung auf 100+ zertifizierte Partner'
    }
  ];

  const values = [
    {
      icon: Shield,
      title: 'Neutralität',
      description: 'Unabhängige und objektive Auditierung ohne Interessenskonflikte'
    },
    {
      icon: Award,
      title: 'Qualität',
      description: 'Höchste Standards in der GDP/GMP-konformen Zertifizierung'
    },
    {
      icon: Users,
      title: 'Partnerschaft',
      description: 'Langfristige Beziehungen zu Kunden und Dienstleistern'
    },
    {
      icon: TrendingUp,
      title: 'Innovation',
      description: 'Kontinuierliche Weiterentwicklung unserer Prozesse und Technologien'
    }
  ];

  return (
    <section id="ueber-uns" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-heading font-bold text-mpc-primary mb-6">
            Über{' '}
            <span className="text-mpc-secondary">MediPharma Connect</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto font-body">
            MPC steht für neutralen, normkonformen Auditierungsprozess in der Pharma-Logistik. 
            Wir sind keine Agentur, sondern ein unabhängiger Qualitätsvermittler.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Mission */}
          <div className="bg-gradient-mpc-light rounded-2xl p-8">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-mpc-primary rounded-full flex items-center justify-center mr-4">
                <Target className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-heading font-bold text-mpc-primary">Mission</h3>
            </div>
            <p className="text-gray-700 font-body leading-relaxed">
              Wir vereinfachen die Lieferantenqualifizierung in der Pharma-Industrie durch 
              zentrale Auditierung und schaffen ein vertrauensvolles Netzwerk qualitätsgeprüfter 
              Dienstleister. Unser Ziel ist es, Zeit und Ressourcen zu sparen, während wir 
              höchste Qualitätsstandards gewährleisten.
            </p>
          </div>

          {/* Vision */}
          <div className="bg-gradient-mpc-light rounded-2xl p-8">
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-mpc-secondary rounded-full flex items-center justify-center mr-4">
                <Eye className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-2xl font-heading font-bold text-mpc-primary">Vision</h3>
            </div>
            <p className="text-gray-700 font-body leading-relaxed">
              Wir streben danach, der führende Standard für Lieferantenqualifizierung in der 
              Pharma-Industrie zu werden. Durch Innovation und Digitalisierung schaffen wir 
              eine transparente, effiziente und vertrauensvolle Plattform für alle Beteiligten 
              der pharmazeutischen Lieferkette.
            </p>
          </div>
        </div>

        {/* Werte */}
        <div className="mb-16">
          <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-8 text-center">
            Unsere Werte
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center p-6 bg-white rounded-xl shadow-sm hover-lift border border-gray-100">
                <div className="w-16 h-16 bg-mpc-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="h-8 w-8 text-mpc-secondary" />
                </div>
                <h4 className="text-lg font-semibold text-mpc-primary mb-3">{value.title}</h4>
                <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Timeline */}
        <div className="bg-gray-50 rounded-2xl p-8 mb-16">
          <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-8 text-center">
            Unsere Meilensteine
          </h3>
          
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-mpc-secondary hidden md:block"></div>
            
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="relative flex items-start">
                  {/* Timeline Dot */}
                  <div className="flex-shrink-0 w-16 h-16 bg-mpc-secondary rounded-full flex items-center justify-center text-white font-bold text-lg mr-6">
                    {milestone.year}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-grow bg-white rounded-xl p-6 shadow-sm">
                    <h4 className="text-lg font-semibold text-mpc-primary mb-2">
                      {milestone.title}
                    </h4>
                    <p className="text-gray-600">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Expertise */}
        <div className="bg-gradient-mpc text-white rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-heading font-bold mb-6">
            Unsere Expertise
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Globe className="h-12 w-12 mx-auto mb-4 opacity-90" />
              <h4 className="text-lg font-semibold mb-2">Internationale Standards</h4>
              <p className="opacity-90">GDP, GMP, ISO 9001 konforme Auditierung</p>
            </div>
            <div>
              <Shield className="h-12 w-12 mx-auto mb-4 opacity-90" />
              <h4 className="text-lg font-semibold mb-2">Regulatorische Compliance</h4>
              <p className="opacity-90">Vollständige Einhaltung aller Pharma-Vorschriften</p>
            </div>
            <div>
              <Users className="h-12 w-12 mx-auto mb-4 opacity-90" />
              <h4 className="text-lg font-semibold mb-2">Erfahrenes Team</h4>
              <p className="opacity-90">Langjährige Expertise in der Pharma-Logistik</p>
            </div>
          </div>
        </div>

        {/* Qualitätsversprechen */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-6">
            Unser Qualitätsversprechen
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex items-center justify-center space-x-3 p-4 bg-gradient-mpc-light rounded-lg">
              <CheckCircle className="h-6 w-6 text-mpc-secondary flex-shrink-0" />
              <span className="font-medium text-gray-700">100% GDP/GMP Konformität</span>
            </div>
            <div className="flex items-center justify-center space-x-3 p-4 bg-gradient-mpc-light rounded-lg">
              <CheckCircle className="h-6 w-6 text-mpc-secondary flex-shrink-0" />
              <span className="font-medium text-gray-700">Neutrale Auditierung</span>
            </div>
            <div className="flex items-center justify-center space-x-3 p-4 bg-gradient-mpc-light rounded-lg">
              <CheckCircle className="h-6 w-6 text-mpc-secondary flex-shrink-0" />
              <span className="font-medium text-gray-700">Kontinuierliche Überwachung</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UeberUns;

