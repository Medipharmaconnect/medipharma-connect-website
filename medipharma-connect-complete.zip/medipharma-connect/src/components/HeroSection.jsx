import React from 'react';
import { ArrowRight, CheckCircle, Users, Shield, Zap } from 'lucide-react';

const HeroSection = () => {
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="pt-16 bg-gradient-to-br from-white via-blue-50/30 to-teal-50/30 min-h-screen flex items-center">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="animate-fade-in-up">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-mpc-primary mb-6 leading-tight">
              Zugang zu qualitätsgeprüften{' '}
              <span className="text-mpc-secondary">Pharma-Dienstleistern</span>{' '}
              – mit nur einer Qualifizierung
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 font-body leading-relaxed">
              MediPharma Connect vereinfacht die Lieferantenqualifizierung: 
              Einmal zertifizieren – Netzwerk nutzen. Sparen Sie Zeit und Ressourcen 
              bei der GxP-konformen Auditierung Ihrer Dienstleister.
            </p>

            {/* USP Highlights */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="flex items-center space-x-3 p-4 bg-white rounded-lg shadow-sm hover-lift">
                <div className="flex-shrink-0">
                  <CheckCircle className="h-6 w-6 text-mpc-secondary" />
                </div>
                <span className="text-sm font-medium text-gray-700">Zentrale Qualifizierung</span>
              </div>
              
              <div className="flex items-center space-x-3 p-4 bg-white rounded-lg shadow-sm hover-lift">
                <div className="flex-shrink-0">
                  <Shield className="h-6 w-6 text-mpc-secondary" />
                </div>
                <span className="text-sm font-medium text-gray-700">Auditberichte auf Abruf</span>
              </div>
              
              <div className="flex items-center space-x-3 p-4 bg-white rounded-lg shadow-sm hover-lift">
                <div className="flex-shrink-0">
                  <Zap className="h-6 w-6 text-mpc-secondary" />
                </div>
                <span className="text-sm font-medium text-gray-700">Schnellere Integration</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up-delay">
              <button 
                onClick={() => scrollToSection('kontakt')}
                className="bg-mpc-secondary text-white px-8 py-4 rounded-lg hover:bg-opacity-90 transition-all duration-200 font-medium hover-lift flex items-center justify-center group"
              >
                Jetzt kostenloses Erstgespräch buchen
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-200" />
              </button>
              
              <button 
                onClick={() => scrollToSection('fuer-unternehmen')}
                className="border-2 border-mpc-primary text-mpc-primary px-8 py-4 rounded-lg hover:bg-mpc-primary hover:text-white transition-all duration-200 font-medium hover-lift"
              >
                Mehr erfahren
              </button>
            </div>
          </div>

          {/* Visual Content */}
          <div className="animate-fade-in-up-delay">
            <div className="relative">
              {/* Main Card */}
              <div className="bg-white rounded-2xl shadow-2xl p-8 relative z-10">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-heading font-bold text-mpc-primary mb-2">
                    Ihr Netzwerk-Dashboard
                  </h3>
                  <p className="text-gray-600">Live-Übersicht Ihrer qualifizierten Partner</p>
                </div>

                {/* Mock Dashboard */}
                <div className="space-y-4">
                  {/* KPI Cards */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-gradient-mpc-light rounded-lg">
                      <div className="text-2xl font-bold text-mpc-primary">47</div>
                      <div className="text-xs text-gray-600">Zertifizierte Partner</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-mpc-light rounded-lg">
                      <div className="text-2xl font-bold text-mpc-secondary">12</div>
                      <div className="text-xs text-gray-600">Aktive Audits</div>
                    </div>
                    <div className="text-center p-4 bg-gradient-mpc-light rounded-lg">
                      <div className="text-2xl font-bold text-green-600">98%</div>
                      <div className="text-xs text-gray-600">Compliance Rate</div>
                    </div>
                  </div>

                  {/* Partner List */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium">LogiPharma GmbH</span>
                      </div>
                      <span className="text-xs text-gray-500">GDP zertifiziert</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium">MedTransport AG</span>
                      </div>
                      <span className="text-xs text-gray-500">GMP zertifiziert</span>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm font-medium">ColdChain Solutions</span>
                      </div>
                      <span className="text-xs text-gray-500">Audit läuft</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Background Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-mpc-secondary/20 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-mpc-primary/10 rounded-full blur-xl"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;

