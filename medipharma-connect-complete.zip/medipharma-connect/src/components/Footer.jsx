import React from 'react';
import { Mail, Phone, MapPin, Shield, FileText, Eye } from 'lucide-react';
import logoWhite from '../assets/MediPharmaConnectLogowhite.png';

const Footer = () => {
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-mpc-primary text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo und Beschreibung */}
          <div className="lg:col-span-2">
            <img 
              src={logoWhite} 
              alt="MediPharma Connect Logo" 
              className="h-10 w-auto mb-4"
            />
            <p className="text-gray-300 mb-4 max-w-md">
              MediPharma Connect vereinfacht die Lieferantenqualifizierung: 
              Einmal zertifizieren – Netzwerk nutzen. Ihr Partner für GDP-konforme 
              Pharma-Logistik und Qualitätssicherung.
            </p>
            <div className="flex space-x-4">
              <div className="flex items-center text-gray-300">
                <Shield className="h-5 w-5 mr-2 text-mpc-secondary" />
                <span className="text-sm">DSGVO-konform</span>
              </div>
              <div className="flex items-center text-gray-300">
                <FileText className="h-5 w-5 mr-2 text-mpc-secondary" />
                <span className="text-sm">GMP/GDP zertifiziert</span>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection('home')}
                  className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200"
                >
                  Startseite
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('fuer-unternehmen')}
                  className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200"
                >
                  Für Unternehmen
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('fuer-dienstleister')}
                  className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200"
                >
                  Für Dienstleister
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('ueber-uns')}
                  className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200"
                >
                  Über uns
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('kontakt')}
                  className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200"
                >
                  Kontakt
                </button>
              </li>
            </ul>
          </div>

          {/* Kontakt */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Kontakt</h3>
            <div className="space-y-3">
              <div className="flex items-center text-gray-300">
                <Mail className="h-5 w-5 mr-3 text-mpc-secondary" />
                <span className="text-sm">info@medipharmaconnect.com</span>
              </div>
              <div className="flex items-center text-gray-300">
                <Phone className="h-5 w-5 mr-3 text-mpc-secondary" />
                <span className="text-sm">+49 (0) 123 456 789</span>
              </div>
              <div className="flex items-start text-gray-300">
                <MapPin className="h-5 w-5 mr-3 text-mpc-secondary mt-0.5" />
                <span className="text-sm">
                  MediPharma Connect<br />
                  Nützenbergerstr. 141<br />
                  42115 Wuppertal
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Trennlinie */}
        <div className="border-t border-gray-600 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            {/* Copyright */}
            <div className="text-gray-300 text-sm mb-4 md:mb-0">
              © 2024 MediPharma Connect. Alle Rechte vorbehalten.
            </div>

            {/* DSGVO Links */}
            <div className="flex flex-wrap gap-6 text-sm">
              <button 
                onClick={() => scrollToSection('datenschutz')}
                className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200 flex items-center"
              >
                <Eye className="h-4 w-4 mr-1" />
                Datenschutzerklärung
              </button>
              <button 
                onClick={() => scrollToSection('impressum')}
                className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200 flex items-center"
              >
                <FileText className="h-4 w-4 mr-1" />
                Impressum
              </button>
              <button 
                onClick={() => scrollToSection('agb')}
                className="text-gray-300 hover:text-mpc-secondary transition-colors duration-200 flex items-center"
              >
                <Shield className="h-4 w-4 mr-1" />
                AGB
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

