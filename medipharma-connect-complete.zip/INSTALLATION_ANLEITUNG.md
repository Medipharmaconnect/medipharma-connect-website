# MediPharma Connect - Installationsanleitung

## 📦 Installation und Setup

### Voraussetzungen
- Node.js (Version 18 oder höher)
- npm oder pnpm
- Git (optional)

### 1. Projekt entpacken
```bash
unzip medipharma-connect-complete.zip
cd medipharma-connect
```

### 2. Abhängigkeiten installieren
```bash
# Mit npm
npm install

# Oder mit pnpm (empfohlen)
pnpm install
```

### 3. Entwicklungsserver starten
```bash
# Mit npm
npm run dev

# Oder mit pnpm
pnpm run dev
```

Die Webseite ist dann unter `http://localhost:5173` erreichbar.

### 4. Production Build erstellen
```bash
# Mit npm
npm run build

# Oder mit pnpm
pnpm run build
```

Die fertigen Dateien befinden sich im `dist/` Ordner.

## 🔧 Anpassungen

### Farben ändern
- Datei: `src/App.css`
- Primärfarbe: `--mpc-primary: #033853`
- Sekundärfarbe: `--mpc-secondary: #28b4ac`

### Inhalte bearbeiten
- **Hero-Section**: `src/components/HeroSection.jsx`
- **Für Unternehmen**: `src/components/FuerUnternehmen.jsx`
- **Für Dienstleister**: `src/components/FuerDienstleister.jsx`
- **Über uns**: `src/components/UeberUns.jsx`
- **Kontakt**: `src/components/Kontakt.jsx`

### Logos austauschen
- Dateien im `src/assets/` Ordner ersetzen
- Pfade in den Komponenten anpassen

### HubSpot-Integration
- Datei: `src/components/Kontakt.jsx`
- Meetings-URL anpassen: `data-src="https://meetings.hubspot.com/mkessen?embed=true"`

## 🚀 Deployment

### Option 1: Statisches Hosting
1. `npm run build` ausführen
2. `dist/` Ordner auf Server hochladen
3. Webserver auf `index.html` zeigen lassen

### Option 2: Vercel/Netlify
1. Repository auf GitHub hochladen
2. Mit Vercel/Netlify verbinden
3. Automatisches Deployment

### Option 3: Eigener Server
1. Build-Dateien auf Server kopieren
2. Nginx/Apache konfigurieren
3. SSL-Zertifikat einrichten

## 📞 Support

Bei Fragen oder Problemen:
- Dokumentation in `README.md` lesen
- Issues auf GitHub erstellen
- Entwickler kontaktieren

---

**© 2024 MediPharma Connect. Erstellt mit React + Vite + Tailwind CSS**

